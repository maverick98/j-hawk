/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.commons.ds.operator;

/**
 *
 * @author manosahu
 */
public interface OperatorConstant {
    String MINUS = "-";
    String PLUS = "+";
    String REFERENCE = "->";
    String LESSER = "<";
    String LESSTHANEQUAL = "<=";
    String GREATER = ">";
    String GREATERTHANEQUAL = ">=";
    String ASSIGN="=";
    String EQUAL = "==";
    
}
