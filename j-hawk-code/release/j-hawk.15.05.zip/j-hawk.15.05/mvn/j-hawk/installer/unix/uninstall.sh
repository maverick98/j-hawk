echo "Removing hawk from /usr/local/bin"
sudo rm /usr/local/bin/hawk
echo "Removing hawk installation directory"
rm -rf ~/.hawk
echo "removing hawk manuage page entry"
sudo rm  /usr/share/man/man1/hawk.1.gz

