/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.hawk.module.script;

/**
 *
 * @author manoranjan
 */
public abstract class AbstractIncludeScript extends SingleLineScript{

}
