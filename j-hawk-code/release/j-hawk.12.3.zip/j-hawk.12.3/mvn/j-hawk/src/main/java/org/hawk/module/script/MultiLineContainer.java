

package org.hawk.module.script;

/**
 *
 * @version 1.0 11 Apr, 2010
 * @author msahu
 */
public class MultiLineContainer {

    private int multiLineStart;
    
    private int start;

    private int end;

    public int getMultiLineStart() {
        return multiLineStart;
    }

    public void setMultiLineStart(int multiLineStart) {
        this.multiLineStart = multiLineStart;
    }

    

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

   

    

    
}




