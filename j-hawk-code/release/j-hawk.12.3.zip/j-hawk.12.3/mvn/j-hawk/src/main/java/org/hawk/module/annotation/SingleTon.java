

package org.hawk.module.annotation;

/**
 *
 * @version 1.0 10 Apr, 2010
 * @author msahu
 */
public @interface SingleTon {

}




