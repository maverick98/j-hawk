/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.hawk.util;

/**
 *
 * @author msahu
 */
public class StringUtil {

    public static boolean isNullOrEmpty(String input){

        return input == null || input.isEmpty();
    }
}
