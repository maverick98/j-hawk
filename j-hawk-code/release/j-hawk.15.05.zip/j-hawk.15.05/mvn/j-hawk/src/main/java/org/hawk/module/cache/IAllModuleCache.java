/*
 * This file is part of j-hawk
 * CopyLeft (C) 2012-2013 Manoranjan Sahu, All Rights are left.
 *
 *  
 *
 * 
 */
package org.hawk.module.cache;

/**
 *
 * @author user
 */
public interface IAllModuleCache extends IModuleCache {

}
