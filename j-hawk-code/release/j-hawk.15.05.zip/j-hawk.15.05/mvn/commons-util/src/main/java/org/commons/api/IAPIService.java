/*
 * This file is part of j-hawk
 * CopyLeft (C) 2012-2013 Manoranjan Sahu, All Rights are left.

 * 
 */


package org.commons.api;

/**
 *
 * @author manosahu
 */
public interface IAPIService {

     
}
