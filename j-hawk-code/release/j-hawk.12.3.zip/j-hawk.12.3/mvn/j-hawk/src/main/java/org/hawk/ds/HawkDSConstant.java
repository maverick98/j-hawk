


package org.hawk.ds;

/**
 *
 * @version 1.0 14 Apr, 2010
 * @author msahu
 */
public class HawkDSConstant {



    public static String INFIX="INFIX";
    public static String POSTFIX="POSTFIX";
    public static String PREFIX="PRETFIX";
}




