/**
  * This file is part of impensa.
  * CopyLeft (C) BigBang<->BigCrunch.All Rights are left.
  *
  * 1) Modify it if you can understand.
  * 2) If you distribute a modified version, you must do it at your own risk.
  *
  */
package org.hawk.module.container;

import org.hawk.module.IModule;

/**
 *
 * @author msahu98
 */
public interface  IContainerModule extends IModule{

}
