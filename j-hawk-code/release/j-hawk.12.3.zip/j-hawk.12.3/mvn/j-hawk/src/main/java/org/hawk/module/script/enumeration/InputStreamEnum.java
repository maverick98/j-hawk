

package org.hawk.module.script.enumeration;

/**
 *
 * @author msahu
 */
public enum InputStreamEnum {

    CONSOLE,FILE
}
